import javax.xml.stream.FactoryConfigurationError;
import java.util.ArrayList;
import java.util.List;

public class Timetable1 implements ITimetable {
    public List<Lesson> list = new ArrayList<Lesson>();

    @Override
    public boolean canBeTransferredTo(Term term, boolean full_time) {
        Lesson testLesson = new Lesson(term, null,null,0);

        return (testLesson.isFullTime() == full_time);

    }

    @Override
    public boolean busy(Term term) {
        for (Lesson idk : list){
            if (term.getDay() == idk.getTerm().getDay())
                if ((idk.getTerm().earlierThan(term.endTerm()) && idk.getTerm().endTerm().laterThan(term)))
                    return true;
        }
        return false;
    }

    @Override
    public boolean put(Lesson lesson) {
        if (!busy(lesson.getTerm())){
            list.add(lesson);
            return true;
        }
        else {
            return false;
        }
    }

    @Override
    public void perform(Action[] actions) {
        int def = 90; //domyslnie o 90 minut?

        int i = 0;
        int l = list.size();

        for(Action act : actions){
            Lesson lesson = list.get(i);
            switch (act){
                case DAY_LATER -> lesson.laterDay();
                case DAY_EARLIER -> lesson.earlierDay();
                case TIME_LATER -> lesson.laterTime(def);
                case TIME_EARLIER -> lesson.earlierTime(def);

            }
            i+=1;
            if (i >= l)
                i = 0;
        }

    }

    @Override
    public Lesson get(Term term) {
        for (Lesson idk : list){
            if (idk.getTerm().equals(term))
                return idk;
        }
        return null;
    }

    @Override
    public String toString() {
        String res = new String();
        Day lastDay = Day.SUN;
        Term lastTerm = new Term(20,0,lastDay);
        Day day = null;
        Term term = null;
        for(int i = 0 ; i < 7 ; i+=1){
            day = Day.values()[i];


//            System.out.println(day);

            res += day.toString()+"\n";
            for(term = new Term(8,0,day) ; term.earlierThan(lastTerm) ; term = term.endTerm()){
//                System.out.print(term);
                res += term.toString();
                if(this.busy(term)) {
                    res += " " + this.get(term).toString(true);
//                    System.out.println(" " + this.get(term).toString(true));
                }
                else {
//                    System.out.println(" ");
                    res += " ";
                }

                res += "\n";
            }
        }
        return res;
    }
}
