public class Term {
    private final int hour;
    private final int minute;
    private int duration;
    private Day day;

    public Term(int hour, int minute){
        this.hour = hour;
        this.minute = minute;
        this.setDuration(90);
    }

    public Term(int hour, int minute, Day day){
        this.hour = hour;
        this.minute = minute;
        this.setDuration(90);
        this.setDay(day);
    }

    private String fixMinuteFormat(){
        if (this.getMinute() < 10)
            return "0" + this.getMinute();

        return Integer.toString(this.getMinute());
    }

    public String toString(boolean onlyStart){
        return (this.getHour() + ":" + fixMinuteFormat());
    }

    public String toString(){
        return (this.getHour() + ":" + fixMinuteFormat() + " [" + this.getDuration() + "]");
    }

    public boolean equals(Term term){
        if (this.getDay() == term.getDay())
            if (this.getHour() == term.getHour())
                if (this.getMinute() == term.getMinute())
                    if (this.getDuration() == term.getDuration())
                        return true;
        
        return false;
    }

    public boolean earlierThan(Term term){
        if (this.getHour() < term.getHour()){
            return true;
        }else if (this.getHour() == term.getHour()){
            if (this.getMinute() < term.getMinute()){
                return true;
            }
        }
        return false;
    }

    public boolean laterThan(Term term){
        if (this.getHour() > term.getHour()){
            return true;
        }else if (this.getHour() == term.getHour()){
            if (this.getMinute() > term.getMinute()){
                return true;
            }
        } 
        return false;
    }

    public Term endTerm(Term term){
        Term res = new Term(this.getHour(), this.getMinute(), this.day);
        res.setDuration((term.getHour() - this.getHour()) * 60 + term.getMinute() - this.getMinute());
        return res;
    }

    public Term endTerm(){
        int hour = this.getHour() + (this.getMinute() + this.getDuration())/60;
        int minute = (this.getMinute() + this.getDuration())%60;

        Term res = new Term(hour, minute, this.day);

        res.setDuration(this.getDuration());

        return res;
    }

    public Term moveTerm(int duration){
        //TODO zmiana dnia za pomoca dodawania czasu
        int hour;
        int minute;
        if (duration > 0) {
            hour = this.getHour() + (this.getMinute() + duration) / 60;
            minute = (this.getMinute() + duration) % 60;
        } else {
            int maxH = 99; // maksymalnie 99 godzin do tylu mozna
            hour = this.getHour() - maxH + (maxH* 60 + this.getMinute() + duration) / 60;
            minute = (maxH * 60 + this.getMinute() + duration) % 60;
        }

        Term res = new Term(hour, minute);

        res.setDuration(this.getDuration());
        res.setDay(this.getDay());

        return res;
    }

    public boolean isFullTime(){
        Lesson idk = new Lesson(this.moveTerm(0), "","",1);
        Term[][] arr = idk.getArr();

        if (arr[this.getDay().ordinal()][0] == null){
            return false;
        }
        return this.laterThan(arr[this.getDay().ordinal()][0]) &&
                this.endTerm().earlierThan(arr[this.getDay().ordinal()][1]);
    }


    public int getHour() {
        return hour;
    }

    public int getMinute() {
        return minute;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public Day getDay() {
        return day;
    }

    public void setDay(Day day) {
        this.day = day;
    }
}
