public enum Action {
    DAY_EARLIER, DAY_LATER, TIME_EARLIER, TIME_LATER;
}
