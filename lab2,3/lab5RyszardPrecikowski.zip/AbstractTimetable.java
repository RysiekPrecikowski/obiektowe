import java.util.ArrayList;
import java.util.List;

public abstract class AbstractTimetable implements ITimetable {
    protected final BasicTerm[][] fullTimeArr = {
            {new BasicTerm(7,59), new BasicTerm(20, 1)},
            {new BasicTerm(7,59), new BasicTerm(20, 1)},
            {new BasicTerm(7,59), new BasicTerm(20,1)},
            {new BasicTerm(7,59), new BasicTerm(20,1)},
            {new BasicTerm(7,59), new BasicTerm(17,1)},
            {null, null},
            {null, null}
    };

    protected final BasicTerm[][] partTimeArr = {
            {null, null},
            {null, null},
            {null, null},
            {null, null},
            {new BasicTerm(16,59), new BasicTerm(20,1)},
            {new BasicTerm(7,59), new BasicTerm(20,1)},
            {new BasicTerm(7,59), new BasicTerm(20,1)},
    };


    public List<Lesson> list = new ArrayList<Lesson>();



    public BasicTerm[][] getFullTimeArr() {
        return fullTimeArr;
    }

    public BasicTerm[][] getPartTimeArr(){
        return partTimeArr;
    }

    public boolean isFullTime(Term term){
        if (fullTimeArr[term.getDay().ordinal()][0] == null){
            return false;
        }
        return term.laterThan(fullTimeArr[term.getDay().ordinal()][0]) &&
                term.endTerm().earlierThan(fullTimeArr[term.getDay().ordinal()][1]);
    }

    public boolean isPartTime(Term term){
        if (partTimeArr[term.getDay().ordinal()][0] == null){
            return false;
        }
        return term.laterThan(partTimeArr[term.getDay().ordinal()][0]) &&
                term.endTerm().earlierThan(partTimeArr[term.getDay().ordinal()][1]);
    }

    public BasicTerm[][] getArr(Term term){
        if (this.isFullTime(term))
            return fullTimeArr;
        else
            return partTimeArr;
    }

    public boolean put(Lesson lesson) {
        if (!busy(lesson.getTerm())){
            if (canBeTransferredTo(lesson.getTerm(), lesson.isFullTime()))
                list.add(lesson);
            return true;
        }

        return false;
    }


    @Override
    public Object get(Term term) {
        for (Lesson l : list){
            if (l.getTerm().equals(term))
                return l;
        }
        return null;
    }


}
