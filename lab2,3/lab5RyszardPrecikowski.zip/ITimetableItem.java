public interface ITimetableItem {

    Object getTerm();


//    boolean equals();
}
