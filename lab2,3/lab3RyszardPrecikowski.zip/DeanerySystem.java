
public class DeanerySystem {
    public static void main(String[] args){
        Term term1 = new Term(9,45);
        System.out.println(term1);                    //Ma się wypisać: "9:45 [90]"
        Term term2 = new Term(10,15);
        System.out.println(term2);                    //Ma się wypisać: "10:15 [90]"
        System.out.println(term1.earlierThan(term2)); //Ma się wypisać: "true"
        System.out.println(term1.equals(term2));      //Ma się wypisać: "false"
        System.out.println(term1.endTerm(term2));
        System.out.println(term1.endTerm());          //Ma się wypisać: "11:15 [90]"

        Day day = Day.SUN;

        System.out.println(day.nextDay());


        Lesson lesson = new Lesson(new Term(16,15,Day.THU),"Programowanie obiektowe","Stanisław Polak",2);
        System.out.println(lesson);

        lesson.earlierDay();

        System.out.println(lesson);

        lesson.earlierTime(40);

        System.out.println(lesson);

        String[] arr ={"t+","t+","d-","d-"};
        Action[] actArr = ActionParser.parse(arr);
        int def = 30; //domyslnie o 30 minut?
        for(Action act : actArr){
            switch (act){
                case DAY_LATER -> lesson.laterDay();
                case DAY_EARLIER -> lesson.earlierDay();
                case TIME_LATER -> lesson.laterTime(def);
                case TIME_EARLIER -> lesson.earlierTime(def);

            }
        }

        System.out.println(lesson);
    }

    
}

