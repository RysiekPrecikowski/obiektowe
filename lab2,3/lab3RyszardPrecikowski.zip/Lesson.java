public class Lesson {
    public Term term;
    public String name;
    public String teacherName;
    public int year;
    public boolean fullTime;

    private Term[][] fullTimeArr = {
            {new Term(7,59), new Term(20,01)},
            {new Term(7,59), new Term(20,01)},
            {new Term(7,59), new Term(20,01)},
            {new Term(7,59), new Term(20,01)},
            {new Term(7,59), new Term(17,01)},
            {null, null},
            {null, null}
    };

    private Term[][] partTimeArr = {
            {null, null},
            {null, null},
            {null, null},
            {null, null},
            {new Term(16,59), new Term(20,01)},
            {new Term(7,59), new Term(20,01)},
            {new Term(7,59), new Term(20,01)},
    };

    public Term[][] getArr(){
        if (this.fullTime)
            return fullTimeArr;
        else
            return partTimeArr;
    }

    public boolean isFullTime(Term term){
        if (fullTimeArr[term.day.ordinal()][0] == null){
            return false;
        }
        return term.laterThan(fullTimeArr[term.day.ordinal()][0]) &&
                term.endTerm().earlierThan(fullTimeArr[term.day.ordinal()][1]);
    }

    public boolean isPartTime(Term term){
        if (partTimeArr[term.day.ordinal()][0] == null){
            return false;
        }
        return term.laterThan(partTimeArr[term.day.ordinal()][0]) &&
                term.endTerm().earlierThan(partTimeArr[term.day.ordinal()][1]);
    }

    public Lesson(Term term, String name, String teacherName, int year){
        this.term = term;
        this.name = name;
        this.teacherName = teacherName;
        this.year = year;
        this.fullTime = isFullTime(term);
    }



    private String type(){
        if (fullTime){
            return "studiow stacjonarnych";
        } else {
            return "studiow niestacjonarnych";
        }
    }
    public String toString() {
        return name + " (" + term.day + " " + term.toString(true) + "-" + term.endTerm().toString(true) + ")" +"\n" +
                year + " rok " + type() + "\n" +
                "Prowadzacy: " + teacherName;
    }

    private boolean moveDay(int n){
        int k = Day.values().length;
        int maxDays = 10 * k;
        int indeks = (maxDays + this.term.day.ordinal() + n) % k;

        Term[][] arr = this.getArr();
        if (arr[indeks][1] == null)
            return false;

        if (this.term.earlierThan(arr[indeks][0]) ||
                this.term.endTerm().laterThan(arr[indeks][1]))
            return false;

        this.term.day = Day.values()[indeks];
        return true;

    }

    public boolean earlierDay(){
        return moveDay(-1);
    }


    public boolean laterDay(){
        return moveDay(1);
    }


    private boolean moveTime(int duration){
        Term newTerm = this.term.moveTerm(duration);
        if (this.fullTime != isFullTime(newTerm))
            return false;

        this.term = newTerm;
        return true;
    }
    public boolean earlierTime(int duration) {
        return moveTime(-duration);
    }

    public boolean laterTime(int duration){

        return moveTime(duration);
    }


}
